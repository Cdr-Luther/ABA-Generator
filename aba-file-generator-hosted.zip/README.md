# ABA File Generator (AU)

Minimal, black/white web app:
- Upload CSV
- Generate bank-ready .ABA (Direct Entry)

## CSV columns (required)
bsb, account_number, account_name, amount, transaction_code, reference

Optional:
withholding_tax

## Deploy (Render - recommended)
1) Create a new Render Web Service from this repo (or upload zip).
2) Set env vars:
- STRIPE_SECRET_KEY
- STRIPE_PRICE_ID
- BASE_URL (https://your-service.onrender.com)

3) Deploy.

## Local run (optional)
pip install -r requirements.txt
uvicorn app.main:app --reload
