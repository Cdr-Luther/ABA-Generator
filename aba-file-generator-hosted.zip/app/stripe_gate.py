import os
import stripe

def stripe_enabled() -> bool:
    return bool(os.getenv("STRIPE_SECRET_KEY")) and bool(os.getenv("STRIPE_PRICE_ID"))

def init_stripe():
    key = os.getenv("STRIPE_SECRET_KEY","").strip()
    if key:
        stripe.api_key = key

def customer_has_active_subscription(customer_id: str) -> bool:
    # Requires STRIPE_SECRET_KEY
    if not customer_id.startswith("cus_"):
        return False
    price_id = os.getenv("STRIPE_PRICE_ID","").strip()
    if not price_id:
        return False

    subs = stripe.Subscription.list(customer=customer_id, status="all", limit=20)
    for s in subs.data:
        if s.status not in ("active","trialing"):
            continue
        for item in s["items"]["data"]:
            if item["price"]["id"] == price_id:
                return True
    return False
