import csv
import io

REQUIRED_COLUMNS = ["bsb","account_number","account_name","amount","transaction_code","reference"]
OPTIONAL_COLUMNS = ["withholding_tax"]

def parse_csv_bytes(data: bytes) -> list[dict]:
    # attempt utf-8-sig first
    text = None
    for enc in ("utf-8-sig","utf-8","cp1252"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ValueError("Could not decode CSV (try UTF-8).")

    reader = csv.DictReader(io.StringIO(text))
    if reader.fieldnames is None:
        raise ValueError("CSV appears empty or missing header row.")

    headers = [h.strip() for h in reader.fieldnames]
    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        raise ValueError(f"CSV missing required columns: {', '.join(missing)}")

    rows = []
    for idx, row in enumerate(reader, start=2):  # row 1 is headers
        r = {k: (row.get(k) or "").strip() for k in REQUIRED_COLUMNS + OPTIONAL_COLUMNS}
        # Basic sanity: don't allow completely blank rows
        if all(v == "" for v in r.values()):
            continue
        rows.append(r)

    if not rows:
        raise ValueError("CSV has no data rows.")
    return rows
