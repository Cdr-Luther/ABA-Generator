import os
from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import stripe

from .csv_parse import parse_csv_bytes
from .aba import generate_aba
from .stripe_gate import init_stripe, stripe_enabled, customer_has_active_subscription

app = FastAPI(title="ABA File Generator", version="1.0.0")
BASE_DIR = os.path.dirname(__file__)
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

def env_bool(name: str, default: bool=False) -> bool:
    v = os.getenv(name, "")
    if v == "":
        return default
    return v.strip().lower() in ("1","true","yes","y","on")

@app.on_event("startup")
def _startup():
    init_stripe()

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {
        "request": request,
        "stripe_enabled": stripe_enabled(),
        "base_url": os.getenv("BASE_URL","").strip(),
    })

@app.post("/create-checkout-session")
async def create_checkout_session(request: Request, email: str = Form(default="")):
    if not stripe_enabled():
        return RedirectResponse(url="/?err=stripe_not_configured", status_code=303)

    base_url = os.getenv("BASE_URL","").strip()
    if not base_url:
        # Render provides X-Forwarded-* headers; fallback to request
        base_url = str(request.base_url).rstrip("/")

    price_id = os.getenv("STRIPE_PRICE_ID").strip()

    session = stripe.checkout.Session.create(
        mode="subscription",
        line_items=[{"price": price_id, "quantity": 1}],
        success_url=f"{base_url}/success?session_id={{CHECKOUT_SESSION_ID}}",
        cancel_url=f"{base_url}/?canceled=1",
        customer_email=email.strip() if email.strip() else None,
        allow_promotion_codes=True,
    )
    return RedirectResponse(url=session.url, status_code=303)

@app.get("/success", response_class=HTMLResponse)
def success(request: Request, session_id: str):
    if not stripe_enabled():
        return RedirectResponse(url="/?err=stripe_not_configured", status_code=303)

    sess = stripe.checkout.Session.retrieve(session_id)
    customer_id = sess.get("customer","")
    return templates.TemplateResponse("success.html", {
        "request": request,
        "customer_id": customer_id,
    })

@app.get("/app", response_class=HTMLResponse)
def app_page(request: Request):
    return templates.TemplateResponse("app.html", {
        "request": request,
        "stripe_enabled": stripe_enabled(),
        "allow_no_stripe": env_bool("ALLOW_NO_STRIPE", False),
    })

@app.post("/generate")
async def generate(
    request: Request,
    csv_file: UploadFile = File(...),
    access_key: str = Form(default=""),
    fi_name: str = Form(...),
    user_name: str = Form(...),
    user_id: str = Form(default=""),
    description: str = Form(default="PAYROLL"),
    process_date: str = Form(default=""),
    remitter_bsb: str = Form(...),
    remitter_account: str = Form(...),
    remitter_name: str = Form(...),
):
    allow_no_stripe = env_bool("ALLOW_NO_STRIPE", False)

    if stripe_enabled():
        if not access_key.strip():
            return templates.TemplateResponse("app.html", {
                "request": request,
                "stripe_enabled": True,
                "allow_no_stripe": allow_no_stripe,
                "error": "Access Key is required (it looks like: cus_...).",
            }, status_code=400)
        if not customer_has_active_subscription(access_key.strip()):
            return templates.TemplateResponse("app.html", {
                "request": request,
                "stripe_enabled": True,
                "allow_no_stripe": allow_no_stripe,
                "error": "Access Key is invalid or subscription is not active.",
            }, status_code=403)
    else:
        if not allow_no_stripe:
            return templates.TemplateResponse("index.html", {
                "request": request,
                "stripe_enabled": False,
                "base_url": os.getenv("BASE_URL","").strip(),
                "error": "Payments are not configured on this deployment (Stripe missing).",
            }, status_code=500)

    data = await csv_file.read()
    rows = parse_csv_bytes(data)

    aba_text = generate_aba(
        fi_name=fi_name,
        user_name=user_name,
        user_id=user_id,
        description=description,
        process_date=process_date,
        remitter_bsb=remitter_bsb,
        remitter_account=remitter_account,
        remitter_name=remitter_name,
        rows=rows,
    )

    filename = "payments.aba"
    headers = {
        "Content-Disposition": f'attachment; filename="{filename}"'
    }
    return Response(content=aba_text, media_type="text/plain; charset=ascii", headers=headers)
