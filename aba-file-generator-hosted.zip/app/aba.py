from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import re
from datetime import datetime

_ALLOWED_CHARS_RE = re.compile(r"^[A-Za-z0-9 \&'\,\-\.\/+\$!%\(\)\*#=:\?\[\]_\^@]*$")

def _clean_text(s: str, max_len: int) -> str:
    s = (s or "").strip()
    # ABA allows many punctuation; we still enforce a safe subset per bank specs
    if not _ALLOWED_CHARS_RE.match(s):
        raise ValueError("Text contains unsupported characters for ABA format.")
    if len(s) > max_len:
        s = s[:max_len]
    return s

def _pad_left(s: str, length: int, fill: str = "0") -> str:
    s = s or ""
    return (fill * max(0, length - len(s))) + s[:length]

def _pad_right(s: str, length: int, fill: str = " ") -> str:
    s = s or ""
    s = s[:length]
    return s + (fill * max(0, length - len(s)))

def _format_bsb(bsb: str) -> str:
    bsb = (bsb or "").strip()
    bsb = bsb.replace(" ", "")
    if re.fullmatch(r"\d{3}-\d{3}", bsb):
        return bsb
    if re.fullmatch(r"\d{6}", bsb):
        return bsb[:3] + "-" + bsb[3:]
    raise ValueError("BSB must be 6 digits (optionally with a hyphen, e.g., 123-456).")

def _format_account_number(acct: str) -> str:
    acct = (acct or "").strip().replace(" ", "")
    if not re.fullmatch(r"\d{1,9}", acct):
        raise ValueError("Account number must be 1–9 digits.")
    return _pad_left(acct, 9, "0")

def _amount_to_cents(amount: str) -> int:
    try:
        d = Decimal(str(amount).strip()).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError):
        raise ValueError("Amount must be a valid number (e.g., 123.45).")
    if d < 0:
        raise ValueError("Amount must be >= 0.")
    return int(d * 100)

@dataclass(frozen=True)
class AbaHeader:
    reel_sequence: str  # "01"
    fi_name: str        # 3 chars, e.g. CBA/WBC/NAB/ANZ
    user_name: str      # 26
    user_id: str        # 6 digits (may be zeros if unknown)
    description: str    # 12, e.g. PAYROLL
    process_date: str   # DDMMYY

    def render(self) -> str:
        # Positions per common DE specs:
        # 1: record type '0'
        # 2-18 spaces
        # 19-20 reel sequence
        # 21-23 FI name
        # 24-30 spaces
        # 31-56 user name
        # 57-62 user id
        # 63-74 description
        # 75-80 date DDMMYY
        # 81-120 spaces
        fi = _pad_right(_clean_text(self.fi_name.upper(), 3), 3, " ")
        if len(fi.strip()) != 3:
            raise ValueError("FI Name must be exactly 3 characters (e.g., CBA, NAB, ANZ, WBC).")
        user_name = _pad_right(_clean_text(self.user_name, 26), 26, " ")
        user_id = (self.user_id or "").strip()
        if user_id == "":
            user_id = "0" * 6
        if not re.fullmatch(r"\d{6}", user_id):
            raise ValueError("User ID must be 6 digits (or leave blank to use 000000).")
        desc = _pad_right(_clean_text(self.description.upper(), 12), 12, " ")
        if desc.strip() == "":
            raise ValueError("File description cannot be blank (e.g., PAYROLL).")
        reel = (self.reel_sequence or "01").strip()
        if not re.fullmatch(r"\d{2}", reel):
            raise ValueError("Reel sequence must be 2 digits (e.g., 01).")

        date = (self.process_date or "").strip()
        if date == "":
            date = datetime.now().strftime("%d%m%y")
        if not re.fullmatch(r"\d{6}", date):
            raise ValueError("Process date must be DDMMYY (e.g., 080126).")

        line = (
            "0"
            + (" " * 17)
            + reel
            + fi
            + (" " * 7)
            + user_name
            + user_id
            + desc
            + date
            + (" " * 40)
        )
        if len(line) != 120:
            raise RuntimeError(f"Header length is {len(line)} (expected 120).")
        return line

@dataclass(frozen=True)
class AbaDetail:
    bsb: str
    account_number: str
    transaction_code: str
    amount: str
    account_title: str
    lodgment_reference: str
    remitter_bsb: str
    remitter_account: str
    remitter_name: str
    withholding_tax: str | None = None

    def render(self) -> tuple[str, int, int, int]:
        # Returns (line, credit_cents, debit_cents, net_cents)
        bsb = _format_bsb(self.bsb)
        acct = _format_account_number(self.account_number)

        code = (self.transaction_code or "").strip()
        if not re.fullmatch(r"\d{2}", code):
            raise ValueError("Transaction code must be 2 digits (e.g., 53 for Pay).")

        cents = _amount_to_cents(self.amount)
        amount_field = _pad_left(str(cents), 10, "0")

        title = _pad_right(_clean_text(self.account_title, 32), 32, " ")
        if title.strip() == "":
            raise ValueError("Account name/title cannot be blank.")

        lodg = _pad_right(_clean_text(self.lodgment_reference, 18), 18, " ")

        rbsb = _format_bsb(self.remitter_bsb)
        racct = _format_account_number(self.remitter_account)
        rname = _pad_right(_clean_text(self.remitter_name, 16), 16, " ")

        # withholding tax: positions 113-120 (8 chars) numeric, zero filled
        wht = (self.withholding_tax or "").strip()
        if wht == "":
            wht_field = "0" * 8
        else:
            wht_cents = _amount_to_cents(wht)
            wht_field = _pad_left(str(wht_cents), 8, "0")

        line = (
            "1"
            + bsb
            + acct
            + " "
            + code
            + amount_field
            + title
            + lodg
            + rbsb
            + racct
            + rname
            + wht_field
        )
        if len(line) != 120:
            raise RuntimeError(f"Detail length is {len(line)} (expected 120).")

        # Most common: codes >= 50 are credits, 13 is debit, etc. We'll compute using simple rule:
        code_int = int(code)
        credit = cents if code_int >= 50 else 0
        debit = cents if code_int < 50 else 0
        net = credit - debit
        return line, credit, debit, net

@dataclass(frozen=True)
class AbaTrailer:
    net_total_cents: int
    credit_total_cents: int
    debit_total_cents: int
    record_count: int

    def render(self) -> str:
        net = _pad_left(str(abs(self.net_total_cents)), 10, "0")
        credit = _pad_left(str(self.credit_total_cents), 10, "0")
        debit = _pad_left(str(self.debit_total_cents), 10, "0")
        count = _pad_left(str(self.record_count), 6, "0")

        line = (
            "7"
            + "999-999"
            + (" " * 12)
            + net
            + credit
            + debit
            + (" " * 24)
            + count
            + (" " * 40)
        )
        if len(line) != 120:
            raise RuntimeError(f"Trailer length is {len(line)} (expected 120).")
        return line

def generate_aba(
    *,
    fi_name: str,
    user_name: str,
    user_id: str,
    description: str,
    process_date: str,
    remitter_bsb: str,
    remitter_account: str,
    remitter_name: str,
    rows: list[dict],
) -> str:
    header = AbaHeader(
        reel_sequence="01",
        fi_name=fi_name,
        user_name=user_name,
        user_id=user_id,
        description=description,
        process_date=process_date,
    ).render()

    details: list[str] = []
    credit_total = 0
    debit_total = 0
    net_total = 0

    for i, r in enumerate(rows, start=1):
        d = AbaDetail(
            bsb=str(r.get("bsb","")),
            account_number=str(r.get("account_number","")),
            transaction_code=str(r.get("transaction_code","")),
            amount=str(r.get("amount","")),
            account_title=str(r.get("account_name","")),
            lodgment_reference=str(r.get("reference","")),
            remitter_bsb=remitter_bsb,
            remitter_account=remitter_account,
            remitter_name=remitter_name,
            withholding_tax=str(r.get("withholding_tax","")) if r.get("withholding_tax") not in (None, "") else None,
        )
        line, credit, debit, net = d.render()
        details.append(line)
        credit_total += credit
        debit_total += debit
        net_total += net

    trailer = AbaTrailer(
        net_total_cents=net_total,
        credit_total_cents=credit_total,
        debit_total_cents=debit_total,
        record_count=len(details),
    ).render()

    # ABA records must be separated by CRLF
    return "\r\n".join([header] + details + [trailer]) + "\r\n"
